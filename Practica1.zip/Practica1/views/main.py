import sys
sys.path.append('../')
#from controls.calculos import Calculos
#from controls.tdaArray import TDAArray
from controls.tda.stack.stackOperation import StackOperation
import json


c=StackOperation()

try:
    c.push("comando 1")
    c.push("comando 2")
    c.push("comando 3")
    c.push("comando 4")
    c.push("comando 5")
    c.push("comando 6")
    c.push("comando 7")
    c.push("comando 8")
    c.push("comando 9")
    c.push("comando 10")
    c.push("comando 11")
    c.push("comando 12")
    c.push("comando 13")
    c.push("comando 14")
    c.push("comando 15")
    c.push("comando 16")
    c.push("comando 17")
    c.push("comando 18")
    c.push("comando 19")
    c.push("comando 20")
    c.push("comando 21")
    c.push("comando 22")

    c.print()
except Exception as error:
    print("errores")
    print(error)

json_data = c.to_json()
print(json_data)

